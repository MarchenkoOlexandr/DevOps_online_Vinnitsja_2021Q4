	<?php get_header(); ?>	
	<?php get_sidebar(); ?>
	<div class="main">
		<div itemscope itemtype="http://schema.org/Article" class="container">
				<noindex><nofollow><div class="post"><center>
				<form action="//3.65.220.230/rezultaty-poiska" id="cse-search-box">  <div>    <input type="hidden" name="cx" value="partner-pub-5443626689609005:mhbawv9vu59" />    <input type="hidden" name="cof" value="FORID:11" />    <input type="hidden" name="ie" value="UTF-8" />    <input type="text" name="q" size="30" />    <input type="submit" name="sa" value="&#x041f;&#x043e;&#x0438;&#x0441;&#x043a;" />  </div></form><script type="text/javascript" src="//www.google.com/cse/brand?form=cse-search-box&amp;lang=ru"></script> 
			</center></div></nofollow></noindex>
			<p><noindex><center> 
				<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
				<!-- pozdravljalka center up 336-280 -->
				<ins class="adsbygoogle"
				style="display:inline-block;width:336px;height:280px"
				data-ad-client="ca-pub-5443626689609005"
				data-ad-slot="7275082656"></ins>
				<script>
					(adsbygoogle = window.adsbygoogle || []).push({});
				</script>
			</noindex></center> </p>
			<div><?php include(TEMPLATEPATH."/pagenavi.php"); ?></div>	
			<div class="pgs"></div>
			<div id="sap">
				<center><h1 itemprop="headline"><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> &raquo; Blog Archive <?php } ?> <?php wp_title(); ?></h1></center>
				<?php if (have_posts()) : ?>
					<?php while (have_posts()) : the_post(); ?>
						<div class="uzor"></div>
						<div class="post"><h2 itemprop="name"><a itemprop="url" href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2></div>
						<script src="//yastatic.net/es5-shims/0.0.2/es5-shims.min.js"></script>
						<script src="//yastatic.net/share2/share.js"></script>
						<div class="ya-share2" data-services="collections,vkontakte,facebook,odnoklassniki,moimir,gplus,twitter,viber" data-url="<?php the_permalink() ?>"></div>
						<div>Тема &gt;&gt;<?php the_category(', ') ?>&nbsp; <?php edit_post_link('Ред'); ?></div>
						<div>
							<?php the_content('<br />Читать пожелания &raquo;'); ?>
						</div>
<meta itemprop="author" content="POZDRAVLJALKA.RU" />
<meta itemprop="datePublished" content="2018" />
<meta itemprop="dateModified" content="2018" />
<div itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
<meta itemprop="address" content="3.65.220.230" />
<meta itemprop="telephone" content="3.65.220.230" />
<div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">
<link itemprop="contentUrl" href="http://3.65.220.230/logos.png" />
<link itemprop="url" href="http://3.65.220.230/logos.png" />
</div>
<meta itemprop="name" content="3.65.220.230" />
</div>
<div itemprop="image" itemscope itemtype="https://schema.org/ImageObject">
<link itemprop="contentUrl" href="http://3.65.220.230/logos.png" />
<link itemprop="url" href="http://3.65.220.230/logos.png" />
</div>
<meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="http://3.65.220.230/logos.png"/>
						<div class="post_text">Мы надеемся, что те поздравления и пожелания, которые есть на сайте понравятся и вам и тем, кому они предназначены. Ведь приятно будет любому человеку услышать в свой адрес красивые поздравления с днем рождения или стихи к Новому году.</div>
					<?php endwhile; ?>
					<div><?php include(TEMPLATEPATH."/pagenavi.php"); ?></div>	
					<noindex><center>
						<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
						<!-- pozdravljalka center down 300-250 -->
						<ins class="adsbygoogle"
						style="display:inline-block;width:300px;height:250px"
						data-ad-client="ca-pub-5443626689609005"
						data-ad-slot="6954207945"></ins>
						<script>
							(adsbygoogle = window.adsbygoogle || []).push({});
						</script>
					</noindex></center> <div class="mobi">
						<div class="post_text"><p>Свято - це приємна і у всіх відносинах радісна подія. Недарма ж кажуть, що наша людина, купуючи календар на майбутній рік, насамперед дивиться - не співпадають вихідні з святковими днями. Так, що не кажи, а погуляти та відпочити ми любимо!</p> 
							<p>Але ось настав ранок після святкового дня, і що приємного ви можете пригадати? А як зробити, щоб замість головного болю від свята залишилося щось цінне і приємне, при згадці про що навіть через багато-багато років піднімався настрій? Ось для того, щоб було що згадати, чому посміхнутися, щоб принести один одному максимум задоволення і мінімум матеріальних витрат, щоб вразити гостей кулінарними талантами, треба іноді звертатися до таких сайтів як наш Поздравлялка.ру. </p>
							<p>У цій книзі ви знайдете цікаву і корисну інформацію про те, як можна прикрасити свято, як скласти і оригінально оформити запрошення, що, як і коли дарувати, а найголовніше - ті самі слова, якими можна достукатися до сердець близьких і рідних людей, щоб викликати в них бурю захоплення і сльози розчулення, тобто як скласти привітання. </p>
							<p>Якщо ви думаєте, що можна обмежитися вітаннями - типу: «Зі святом тебе я вітаю, щастя, радості бажаю ...», то ви глибоко помиляєтеся. Не вірите? Тоді прочитайте наш сайт - і ви зрозумієте, що завжди можна знайти приємні слова не тільки в день народження або в день весілля, а й у будь професійне свято. </p>
							<p>Але не думайте, що ми пропонуємо вам програму дій, виконання якої в будь-який святковий день потрібно слідувати неухильно. Це не так, тому що ви і тільки ви повинні стати тим самим творчим початком, від якого залежать результат свята і відмінний настрій кожного з гостей, родичів або друзів. </p>   </div></div>
							<!--noindex--><center>
							</center><!--/noindex-->
						<?php else : ?>
							<h2 class="center">Поздравления и пожелания - Привітання та побажання</h2>
							<div class="post_text">
								<p>Возможно на нашем сайте "Трогательные поздравления добрые пожелания" вы не нашли нужного материала. Однако на нашем сайте есть множество поздравлений и пожеланий, которые помогут вам поздравить к примеру с днем рождения любимых и близких вам людей, а также поздравить их с праздниками, как с Новым годом, с 23 февраля и свадьбой, так и с 8 марта или другие поздравления любимым или любимой. Найти необходимый материал вы можете воспользовавшись поиском.
									<noindex><nofollow><div class="post"><center>
										<form action="//3.65.220.230/rezultaty-poiska" id="cse-search-box">  <div>    <input type="hidden" name="cx" value="partner-pub-5443626689609005:mhbawv9vu59" />    <input type="hidden" name="cof" value="FORID:11" />    <input type="hidden" name="ie" value="UTF-8" />    <input type="text" name="q" size="30" />    <input type="submit" name="sa" value="&#x041f;&#x043e;&#x0438;&#x0441;&#x043a;" />  </div></form><script type="text/javascript" src="//www.google.com/cse/brand?form=cse-search-box&amp;lang=ru"></script> 
									</center></div></nofollow></noindex>		
								<?php endif; ?>
							</div>
						</div></div>
						<?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
						<?php get_footer(); ?>