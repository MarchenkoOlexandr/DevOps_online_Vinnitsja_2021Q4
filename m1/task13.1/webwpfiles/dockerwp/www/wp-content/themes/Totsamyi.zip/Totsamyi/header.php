<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN" "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html itemscope itemtype="http://schema.org/WebPage" version="XHTML+RDFa 1.0" xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="yandex-verification" content="0a53fa1974c99b86" />
<link rel="stylesheet" type="text/css" href="http://3.65.220.230/wp-content/themes/Totsamyi/style.css">
<!--[if lt IE 9]><script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
<title itemprop="headline"><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
<link rel="shortcut icon" href="http://3.65.220.230/favicon.ico" />
<link rel="icon" href="http://3.65.220.230/favicon.ico" />
<meta http-equiv="content-language" content="ru,uk" />
<meta property="og:image" content="http://3.65.220.230/logos.png" />
<meta property="og:type" content="article" />
<meta property="og:locale" content="ru_RU" />
<meta name="google-site-verification" content="6jNiZv8OamUh2Rb7XwoclU7hDvMGgcafuaMLHfq_2zg" />
<link rel="home" title="Трогательные поздравления добрые пожелания" href="http://3.65.220.230/" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<?php wp_head(); ?>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script src="//3.65.220.230/wp-content/themes/Totsamyi/clipboard.min.js"></script>
<script>new Clipboard('.btn-clipboard');</script>
<script>(adsbygoogle = window.adsbygoogle || []).push({google_ad_client: "ca-pub-5443626689609005",enable_page_level_ads: true});</script>
<!--noindex-->
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-5443626689609005",
          enable_page_level_ads: true
     });
</script>
<!--/noindex-->
</head>
<script type="text/javascript">
	jQuery(document).ready(function($){
		$('.icon-menu').click(function(event){
				$('.sideb').toggleClass('active');
				$('.icon-menu').toggleClass('active');
		});
	});
</script>
<body>
	<div itemscope itemtype="http://schema.org/WPHeader" id="header">
<a itemprop="url" href="/" title="Трогательные поздравления добрые пожелания">
<div class="log"></div></a>
</div>
<div class="icon-menu"></div>
<div class="clearfix"></div>
<div id="wrapper">