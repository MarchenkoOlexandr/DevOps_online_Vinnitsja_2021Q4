<?php
/*
Template Name: Golos
*/
?>
<?php include("headergol.php"); ?>
<div class="post_textgol">
<center><h1 class="post_textgol">Поздравления к праздникам в стихах и прозе</h1></center>
<table width="80%" border="0" cellspacing="0" cellpadding="5" align="center"><tr><td>
<li><a href="//3.65.220.230/pozdravleniya-s-dnem-rozhdeniya">Поздравления с днем рождения</a></li>
<li><a href="//3.65.220.230/prikolnye-pozdravleniya-s-dnem-rozhdeniya">Прикольные поздравления с днем рождения</a></li>
<li><a href="//3.65.220.230/pozdravleniya-detyam">Поздравления детям</a></li>
<li><a href="//3.65.220.230/pozdravleniya-s-dnem-rozhdeniya-zhenshhine">Поздравления с днем рождения женщине</a></li>
<li><a href="//3.65.220.230/pozdravleniya-s-dnem-rozhdeniya-muzhchine">Поздравления с днем рождения мужчине</a></li>
<li><a href="//3.65.220.230/yubilej">Юбилей</a></li>
<li><a href="//3.65.220.230/pozdravleniya-budushhim-mamam-i-papam">Поздравления будущим мамам и папам</a></li>
<li><a href="//3.65.220.230/svadebnye-pozdravleniya">Свадебные поздравления</a></li>
<li><a href="//3.65.220.230/sms-lyubimym">Смс любимому и Sms любимой</a></li>
<li><a href="//3.65.220.230/pozdravleniya-s-novym-godom">Поздравления с Новым годом</a></li>
<li><a href="//3.65.220.230/pozdravleniya-s-rozhdestvom-xristovym">Поздравления с Рождеством Христовым</a></li>
<li><a href="//3.65.220.230/pozdravleniya-s-dnem-sv-valentina">Поздравления с днем св. Валентина</a></li>
<li><a href="//3.65.220.230/pozdravleniya-s-23-fevralya">Поздравления с 23 февраля</a></li></td><td>
<li><a href="//3.65.220.230/pozdravleniya-s-8-marta">Поздравления с 8 марта</a></li>
<li><a href="//3.65.220.230/den-studenta">День студента</a></li>
<li><a href="//3.65.220.230/na-vypusknoj">На выпускной</a></li>
<li><a href="//3.65.220.230/den-medrabotnika">День медработника</a></li>
<li><a href="//3.65.220.230/den-vdv">День ВДВ</a></li>
<li><a href="//3.65.220.230/den-znanij-1-sentyabrya">День знаний &#8211; 1 сентября</a></li>
<li><a href="//3.65.220.230/imennye-pozdravleniya">Именные поздравления</a></li>
<li><a href="//3.65.220.230/dobroe-utro-lyubimaya-dobroe-utro-lyubimyj">Доброе утро любимая &#8211; Доброе утро любимый</a></li>
<li><a href="//3.65.220.230/pozhelaniya-spokojnoj-nochi">Пожелания спокойной ночи</a></li>
<li><a href="//3.65.220.230/originalnye-pozdravleniya">Оригинальные поздравления</a></li>
<li><a href="//3.65.220.230/pozhelaniya-2">Пожелания</a></li>
<li><a href="//3.65.220.230/professionalnye-pozdravleniya">Профессиональные поздравления</a></li>
<li><a href="//3.65.220.230/professionalnye-prazdniki">Профессиональные праздники</a></li></td><td><td>
<li><a href="//3.65.220.230/privitannya-z-dnem-narodzhennya">Привітання з днем народження</a></li>
<li><a href="//3.65.220.230/novorichni-privitannya">Новорічні привітання</a></li>
<li><a href="//3.65.220.230/privitannya-na-rizdvo">Привітання на Різдво</a></li>
<li><a href="//3.65.220.230/privitannya-z-dnem-valentina">Привітання з днем Валентина</a></li>
<li><a href="//3.65.220.230/vitannya-z-23-lyutogo">Вітання з 23 лютого</a></li>
<li><a href="//3.65.220.230/privitannya-z-8-bereznya">Привітання з 8 березня</a></li>
<li><a href="//3.65.220.230/s-pashoj-z-velikodnem">С Пасхой &#8211; З Великоднем</a></li>
<li><a href="//3.65.220.230/otkrytki-s-dnem-rozhdeniya">Открытки с днем рождения</a></li>
<li><a href="//3.65.220.230/otkrytki-s-8-marta">Открытки с 8 марта</a></li></td></table>
    	</div>
<div id="bloggol1" align="center">Голосовые аудио поздравления на мобильный</div>
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<?php the_content('<p class="serif">Читать поздравления &raquo;</p>'); ?>


		<?php endwhile; endif; ?>
        