	<div itemscope itemtype="http://schema.org/WPSideBar" class="sideb2">
		<div class="titlvid">На мобильный</div>
		<div class="vid">
			<!--noindex-->

<!--/noindex-->
</div> 
<div class="vidrec">
	<?php
	if (is_front_page() ) {
   echo('<!--noindex--><center>

</center><!--/noindex-->'); // действие для главной страницы
 } else {
 	echo('<div class="titlvidr">Цікавинки:</div>
 		<div class="vidrec"><!--noindex--><center><script type="text/javascript"><!--
 		google_ad_client = "ca-pub-5443626689609005";
 		/* 160x600, создано 04.01.11 */
 		google_ad_slot = "6244072333";
 		google_ad_width = 160;
 		google_ad_height = 600;
//-->
 		</script>
 		<script type="text/javascript"
 		src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script></center><!--/noindex--></div>'); // действие для не главной страницы
 }
 ?>
</div> 
<div class="titlvid">Обратите внимание:</div>
<div class="vid">
	<!--noindex--><nofollow><center>
<a target="_blank" href="https://www.telderi.ru/ru/viewsite/1578672/pid/9c2cfd"><img src="https://www.telderi.ru/uploads/promote/auction_website_basket_blue_50.gif" alt="" /></a>
	</center>
	<center>
<div id="venus-85159"></div>
<script type="text/javascript">
var venus85159 = { blockId: "85159", async: true };
(function (w, d, o, t) {
o.send = function () {
(o.queue = o.queue || []).push(arguments);
};
var s = d.createElement(t);
if (o.async) s.async = 1;
s.src = "https://block.sw2block.com/rotator/85159.js";
var i = d.getElementsByTagName(t)[0];
i.parentNode.insertBefore(s, i);
o.send("pageview");
})(window, document, venus85159, "script");
</script>
	</center>
</nofollow><!--/noindex-->
</div> 
<!--noindex--><nofollow>

</nofollow><!--/noindex-->
</div>