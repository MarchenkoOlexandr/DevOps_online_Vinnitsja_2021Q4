		<div class="clearfix">
			<div itemscope itemtype="http://schema.org/WPSideBar" class="sideb">
				<div class="titlvid">Поздравления</div>
				<div itemscope itemtype="http://www.schema.org/SiteNavigationElement" class="vid">
					<ul><li itemprop="name"><a itemprop="url" href="//3.65.220.230/tserkovnyie-prazdniki">Церковные праздники</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/professionalnye-prazdniki">Праздники</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/kalendar-imenin">Календарь именин</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozdravleniya-s-dnem-rozhdeniya">С днем рождения</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/prikolnye-pozdravleniya-s-dnem-rozhdeniya">Прикольные с днем рождения</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozdravleniya-detyam">Детям</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozdravleniya-s-dnem-rozhdeniya-zhenshhine">С днем рождения женщине</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozdravleniya-s-dnem-rozhdeniya-muzhchine">С днем рождения мужчине</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/yubilej">Юбилей</a></li>
						<ul>
							<li itemprop="name"><a itemprop="url" href="http://3.65.220.230/yubilej/yubiley-16-let">Юбилей 16 лет</a></li>
							<li itemprop="name"><a itemprop="url" href="http://3.65.220.230/yubilej/yubiley-18-let">Юбилей 18 лет</a></li>
							<li itemprop="name"><a itemprop="url" href="http://3.65.220.230/yubilej/yubiley-20-let">Юбилей 20 лет</a></li>
							<li itemprop="name"><a itemprop="url" href="http://3.65.220.230/yubilej/yubiley-25-let">Юбилей 25 лет</a></li>
							<li itemprop="name"><a itemprop="url" href="http://3.65.220.230/yubilej/yubiley-30-let">Юбилей 30 лет</a></li>
							<li itemprop="name"><a itemprop="url" href="http://3.65.220.230/yubilej/yubiley-35-let">Юбилей 35 лет</a></li>
							<li itemprop="name"><a itemprop="url" href="http://3.65.220.230/yubilej/yubiley-40-let">Юбилей 40 лет</a></li>
							<li itemprop="name"><a itemprop="url" href="http://3.65.220.230/yubilej/yubiley-45-let">Юбилей 45 лет</a></li>
							<li itemprop="name"><a itemprop="url" href="http://3.65.220.230/yubilej/yubiley-50-let">Юбилей 50 лет</a></li>
							<li itemprop="name"><a itemprop="url" href="http://3.65.220.230/yubilej/yubiley-55-let">Юбилей 55 лет</a></li>
							<li itemprop="name"><a itemprop="url" href="http://3.65.220.230/yubilej/yubiley-60-let">Юбилей 60 лет</a></li>
						</ul>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozdravleniya-budushhim-mamam-i-papam">Будущим мамам и папам</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/svadebnye-pozdravleniya">Свадебные</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/sms-lyubimym">Смс любимому и Sms любимой</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozdravleniya-s-novym-godom">С Новым годом</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozdravleniya-s-rozhdestvom-xristovym">С Рождеством Христовым</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/den-studenta">День студента</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozdravleniya-s-dnem-sv-valentina">С днем св. Валентина</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozdravleniya-s-23-fevralya">С 23 февраля</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozdravleniya-s-8-marta">С 8 марта</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozdravleniya-s-1-aprelya">С 1 апреля</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/s-pashoj-z-velikodnem">С Пасхой</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/na-vypusknoj">На выпускной</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/den-medrabotnika-stihi">День медработника</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/den-vdv">День ВДВ</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/den-znanij-1-sentyabrya">День знаний 1 сентября</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/imennye-pozdravleniya">Именные</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/dobroe-utro-lyubimaya-dobroe-utro-lyubimyj">Доброе утро любимая &#8211; Доброе утро любимый</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozhelaniya-spokojnoj-nochi">Пожелания спокойной ночи</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/originalnye-pozdravleniya">Оригинальные</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/pozhelaniya-2">Пожелания</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/professionalnye-pozdravleniya">Профессиональные</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/privitannya-z-dnem-narodzhennya">Привітання з днем народження</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/privitannya-z-dnem-angela">Привітання з днем ангела</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/vesilni-vitannya">Весільні вітання</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/novorichni-privitannya">Новорічні привітання</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/privitannya-na-rizdvo">Привітання на Різдво</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/privitannya-z-dnem-valentina">Привітання з днем Валентина</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/vitannya-z-23-lyutogo">Вітання з 23 лютого</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/privitannya-z-8-bereznya">Привітання з 8 березня</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/otkrytki-s-dnem-rozhdeniya">Открытки с днем рождения</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/otkrytki-s-8-marta">Открытки с 8 марта</a></li>
						<li itemprop="name"><a itemprop="url" href="//3.65.220.230/otkrytki-s-novym-godom">Открытки с Новым годом</a></li>
					</ul>
				</div> 
				<div class="titlvidr">Немного рекламы:</div>
				<div class="vidrec">
					<?php
					if (is_front_page() ) {
   echo('<!--noindex--><center></center><!--/noindex-->'); // действие для главной страницы
 } else {
   echo('<!--noindex--><!--/noindex-->'); // действие для не главной страницы
 }
 ?>
 <!--noindex-->
 <!--/noindex-->
</div> 
</div></div>